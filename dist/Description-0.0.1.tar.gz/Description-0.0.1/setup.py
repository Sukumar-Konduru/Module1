from setuptools import setup

setup(
    name='Description',
    version='0.0.1',
    description='a pip-installable package example',
    license='MIT',
    packages=['Animals'],
    author='Sukumar.Konduru_2-7',
    author_email='konduru.sukumar52@gmail.com',
    keywords=['example'],
    url='https://github.com/bgse/Description'
)