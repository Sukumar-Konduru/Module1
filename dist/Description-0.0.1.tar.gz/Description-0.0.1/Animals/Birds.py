class Birds:
    def __init__(self):
        print('Birds class object is created')
    def getBirdType(self):
        print('getBirdType method is called')